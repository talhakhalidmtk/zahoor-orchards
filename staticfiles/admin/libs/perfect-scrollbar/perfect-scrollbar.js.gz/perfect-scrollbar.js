import PerfectScrollbar from 'perfect-scrollbar/dist/perfect-scrollbar';

export { PerfectScrollbar };
